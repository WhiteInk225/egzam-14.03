package com.example.aplikacja_desktopowa;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private TextField firstName;
    @FXML
    private TextField lastName;
    @FXML
    private ChoiceBox<String> position;
    @FXML
    private TextField charNumber;
    @FXML
    private CheckBox caseType;
    @FXML
    private CheckBox numbers;
    @FXML
    private CheckBox specialLetters;
    @FXML
    private Button generatePassword;
    @FXML
    private Button accept;

    ObservableList<String> positionList = FXCollections.observableArrayList("Kierownik", "Starszy programista", "Młodszy programista", "Tester");

    private String finalPassword = "";

    @FXML
    private void initialize() {
        caseType.setSelected(true);
        position.setItems(positionList);
    }

    @FXML
    private void generatePassword() {
        int length = 0;
        try {
            length = Integer.parseInt(charNumber.getText());
        } catch (NumberFormatException e) {
            welcomeText.setText("Podaj poprawną długość hasła.");
            return;
        }

        int requiredTypes = 0;
        if (caseType.isSelected()) requiredTypes++;
        if (numbers.isSelected()) requiredTypes++;
        if (specialLetters.isSelected()) requiredTypes++;

        if (length < requiredTypes) {
            welcomeText.setText("Haslo musi mięć minimum " + requiredTypes + " znaków.");
            return;
        }

        StringBuilder passwordCharacters = new StringBuilder();
        List<String> requiredCharacters = new ArrayList<>();

        if (caseType.isSelected()) {
            passwordCharacters.append("abcdefghijklmnopqrstuvwxyz");
            requiredCharacters.add("abcdefghijklmnopqrstuvwxyz".charAt(new SecureRandom().nextInt(26)) + "");
        }

        if (caseType.isSelected()) {
            passwordCharacters.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            requiredCharacters.add("ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(new SecureRandom().nextInt(26)) + "");
        }

        if (numbers.isSelected()) {
            passwordCharacters.append("0123456789");
            requiredCharacters.add("0123456789".charAt(new SecureRandom().nextInt(10)) + "");
        }

        if (specialLetters.isSelected()) {
            passwordCharacters.append("!@#$%^&*()-_=+[{]}\\\\|;:'\\\",<.>/?");
            requiredCharacters.add("!@#$%^&*()-_=+[{]}\\\\|;:'\\\",<.>/?".charAt(new SecureRandom().nextInt(32)) + "");
        }

        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();

        for (String charItem : requiredCharacters) {
            password.append(charItem);
        }

        for (int i = password.length(); i < length; i++) {
            int index = random.nextInt(passwordCharacters.length());
            password.append(passwordCharacters.charAt(index));
        }

        List<Character> passwordList = new ArrayList<>();
        for (int i = 0; i < password.length(); i++) {
            passwordList.add(password.charAt(i));
        }
        java.util.Collections.shuffle(passwordList);

        StringBuilder finalPasswordBuilder = new StringBuilder();
        for (Character c : passwordList) {
            finalPasswordBuilder.append(c);
        }

        finalPassword = finalPasswordBuilder.toString();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Utworzono hasło");
        alert.setContentText(finalPassword);
        alert.showAndWait();
        System.out.println("Hasło to: " + finalPassword);
    }

    @FXML
    private void onAcceptClick() {
        String firstNameText = firstName.getText();
        String lastNameText = lastName.getText();
        String selectedPosition = position.getValue();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Utworzono użytkownika");
        alert.setContentText("Dane użytkownika:\nImię: " + firstNameText + "\nNazwisko: " + lastNameText + "\nStanowisko: " + selectedPosition + "\nHasło: " + finalPassword);
        alert.showAndWait();
    }

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
}
