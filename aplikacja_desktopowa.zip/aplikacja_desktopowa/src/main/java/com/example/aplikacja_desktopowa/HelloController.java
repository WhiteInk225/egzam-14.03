package com.example.aplikacja_desktopowa;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private Label firstName;
    @FXML
    private Label lastName;
    @FXML
    private ChoiceBox position;
    @FXML
    private int charNumber;
    @FXML
    private boolean caseType;
    @FXML
    private boolean numbers;
    @FXML
    private boolean specialLetters;

    ObservableList<String> positionList = FXCollections.observableArrayList("Kierownik","Starszy programista","Młodszy programista","Tester");
    @FXML
    private void generatePassword(){

    }



    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
}